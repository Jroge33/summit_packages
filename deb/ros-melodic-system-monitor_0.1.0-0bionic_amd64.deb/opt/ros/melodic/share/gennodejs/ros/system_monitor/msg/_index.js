
"use strict";

let MEMStatus = require('./MEMStatus.js');
let CoreUsage = require('./CoreUsage.js');
let DiagnosticCPUUsage = require('./DiagnosticCPUUsage.js');
let NetStatus = require('./NetStatus.js');
let Interface = require('./Interface.js');
let DiagnosticCPUTemperature = require('./DiagnosticCPUTemperature.js');
let Disk = require('./Disk.js');
let CoreTemp = require('./CoreTemp.js');
let DiagnosticHDD = require('./DiagnosticHDD.js');
let CPUUsageStatus = require('./CPUUsageStatus.js');
let DiagnosticMEM = require('./DiagnosticMEM.js');
let HDDStatus = require('./HDDStatus.js');
let CPUTemperatureStatus = require('./CPUTemperatureStatus.js');
let Diagnostic = require('./Diagnostic.js');
let DiagnosticNET = require('./DiagnosticNET.js');
let Memory = require('./Memory.js');
let MEMStatus = require('./MEMStatus.js');
let CoreUsage = require('./CoreUsage.js');
let DiagnosticCPUUsage = require('./DiagnosticCPUUsage.js');
let NetStatus = require('./NetStatus.js');
let Interface = require('./Interface.js');
let DiagnosticCPUTemperature = require('./DiagnosticCPUTemperature.js');
let Disk = require('./Disk.js');
let CoreTemp = require('./CoreTemp.js');
let DiagnosticHDD = require('./DiagnosticHDD.js');
let CPUUsageStatus = require('./CPUUsageStatus.js');
let DiagnosticMEM = require('./DiagnosticMEM.js');
let HDDStatus = require('./HDDStatus.js');
let CPUTemperatureStatus = require('./CPUTemperatureStatus.js');
let Diagnostic = require('./Diagnostic.js');
let DiagnosticNET = require('./DiagnosticNET.js');
let Memory = require('./Memory.js');

module.exports = {
  MEMStatus: MEMStatus,
  CoreUsage: CoreUsage,
  DiagnosticCPUUsage: DiagnosticCPUUsage,
  NetStatus: NetStatus,
  Interface: Interface,
  DiagnosticCPUTemperature: DiagnosticCPUTemperature,
  Disk: Disk,
  CoreTemp: CoreTemp,
  DiagnosticHDD: DiagnosticHDD,
  CPUUsageStatus: CPUUsageStatus,
  DiagnosticMEM: DiagnosticMEM,
  HDDStatus: HDDStatus,
  CPUTemperatureStatus: CPUTemperatureStatus,
  Diagnostic: Diagnostic,
  DiagnosticNET: DiagnosticNET,
  Memory: Memory,
  MEMStatus: MEMStatus,
  CoreUsage: CoreUsage,
  DiagnosticCPUUsage: DiagnosticCPUUsage,
  NetStatus: NetStatus,
  Interface: Interface,
  DiagnosticCPUTemperature: DiagnosticCPUTemperature,
  Disk: Disk,
  CoreTemp: CoreTemp,
  DiagnosticHDD: DiagnosticHDD,
  CPUUsageStatus: CPUUsageStatus,
  DiagnosticMEM: DiagnosticMEM,
  HDDStatus: HDDStatus,
  CPUTemperatureStatus: CPUTemperatureStatus,
  Diagnostic: Diagnostic,
  DiagnosticNET: DiagnosticNET,
  Memory: Memory,
};
