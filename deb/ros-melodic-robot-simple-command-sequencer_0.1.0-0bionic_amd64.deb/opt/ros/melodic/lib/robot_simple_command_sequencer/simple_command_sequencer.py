#!/usr/bin/env python2
import re

import rospy
import actionlib

from std_msgs.msg import String, Empty
from std_srvs.srv import Trigger, TriggerResponse

from robot_simple_command_manager_msgs.msg import *
from robot_simple_command_manager_msgs.srv import SetCommandString, SetCommandStringResponse
from actionlib_msgs.msg import GoalStatus
from rcomponent.rcomponent import *

import Queue
import datetime
"""
    QUEUE of SequenceList
        SequenceList:
                SEQ1 SEQ2 ... SQn [LOOP]
                    SEQx -> [CMD1 CMD2 .. CMDn]
"""


class SequenceList():
    """
        Manages the list of sequences
    """

    def __init__(self, sequences):
        """
            Args:
                - sequences: string[] with all the sequences in the list
        """
        # Array of sequences
        self.sequences_string = sequences
        self.sequences = []
        self.current_sequence_index = 0
        self.id = ' '.join([str(elem) for elem in self.sequences_string])

        #
        self.loop = False
        self.loop_cycles = 0
        #
        self._creation_datetime = datetime.datetime.now()
        self._creation_rostime = rospy.Time.now()
        self._id = self._creation_datetime.strftime("SL-%Y%m%d-%H%M%S")

    def get_id(self):
        """
            Returns object id as string
        """

        return self.id

    def set_loop(self, value):
        """
            Sets the command loop option
        """
        self.loop = value

    def is_loop(self):
        """
            Returns if loop is enabled for this command
        """
        return self.loop

    def get_loop_cycles(self):
        """
            Returns the number of completed loops
        """
        return self.loop_cycles

    def append(self, sequence_id, commands):
        """
            Adds a new sequence

            Args:
                sequence_id: string as the sequence id
                commands: string [] as the commands that contains the sequence
        """
        self.sequences.append(Sequence(sequence_id, commands))

    def reset(self):
        """
            Resets the list of sequences
        """
        for sequence in self.sequences:
            sequence.reset()
        self.current_sequence_index = 0
        if self.loop:
            self.loop_cycles += 1

    def _get_current_sequence(self):
        """
            Gets the current sequence
        """
        if self.current_sequence_index >= len(self.sequences):
            return None
        else:
            return self.sequences[self.current_sequence_index]

    def get_next_command(self):
        """
            Gets the next command of the current sequence
            Returns:
                - The next command as string
                - None if there are no more command in the sequence list
        """
        while True:
            current_sequence = self._get_current_sequence()
            # No more sequences nor commands
            if current_sequence == None:
                return None

            command = current_sequence.get_next_command()

            if command == None:  # No more commands in the sequence
                self.current_sequence_index += 1  # increase the sequence
            else:
                return command

    def get_current_sequence_id(self):
        """
            Returns the current sequence id as string
            Returns None if the sequences finished
        """
        current_sequence = self._get_current_sequence()
        # No more sequences nor commands
        if current_sequence == None:
            return None
        else:
            return current_sequence.get_id()


class Sequence():
    """
        A sequence is a list of simple commands
    """

    def __init__(self, id, commands):
        """
            Args:
                id: String
                commands: String[]
        """
        self.id = id
        self.commands = commands
        self.current_command_index = 0
        #
        self._creation_datetime = datetime.datetime.now()
        self._creation_rostime = rospy.Time.now()
        self._id = self._creation_datetime.strftime("S-%Y%m%d-%H%M%S")

    def reset(self):
        """
        Resets the sequence of commands, starting from the begining
        """
        self.current_command_index = 0

    def get_next_command(self):
        """
            Gets the next command in the list
        """
        if self.current_command_index >= len(self.commands):
            return None
        else:
            command = self.commands[self.current_command_index]
            self.current_command_index += 1
            return command

    def get_id(self):
        """
            Gets the id of the sequence
        """
        return self.id


class SimpleCommandSequencer(RComponent):
    """
    A class used to load simple command handlers

    ...


    """

    def __init__(self):
        self.feedback_msg = CommandStringFeedback()
        self.feedback_action_msg = RobotSimpleCommandFeedback()
        self.action_client_feedback_msg = None
        # Available sequences of commands
        self.sequences_dict = {}
        # sequence list of commands in execution
        self.current_sequence_list = None
        self.current_sequence_list_id = ''
        # current command sent/in execution
        self.current_command = ''
        # Saves the time of the feedback msg
        self.last_time_received_action_client_feedback = rospy.Time(0)
        # Timeout to control the lack of communication from the action server
        self.communication_timeout = rospy.Duration.from_sec(10)
        self.maxsize_queue = 100
        # Queue of sequence list to execute
        self.sequences_list_queue = Queue.Queue(maxsize=self.maxsize_queue)
        # Flag to enable/disable adding sequences into the queue
        self.allow_queuing = False
        # Contains the words cannot be used as sequence ids
        self._sequence_reserved_keywords = ['LOOP']

        RComponent.__init__(self)

    def ros_read_params(self):
        """Gets params from param server"""
        RComponent.ros_read_params(self)
        self.sequences_dict = rospy.get_param('~sequences', {})
        self.action_client_namespace = rospy.get_param('~action_client_namespace', 'command_manager/action')
        self.allow_queuing = rospy.get_param('~allow_queuing', False)
        self.validate_sequence_keywords()

    def ros_setup(self):
        """Creates and inits ROS components"""

        RComponent.ros_setup(self)

        self.command_sub = rospy.Subscriber('~command', CommandString, self.topic_cmd_cb)
        self.command_cancel_sub = rospy.Subscriber('~cancel', Empty, self.topic_cmd_cancel_cb)

        self.command_feedback_pub = rospy.Publisher(
            '~feedback', CommandStringFeedback, queue_size=1)

        self.command_service = rospy.Service('~command', SetCommandString, self.service_cmd_cb)
        self.command_cancel_service = rospy.Service('~cancel', Trigger, self.service_cmd_cancel_cb)

        self.command_action_server = actionlib.SimpleActionServer('~action', RobotSimpleCommandAction, None, False)
        self.command_action_server.register_goal_callback(self.action_goal_cb)
        self.command_action_server.register_preempt_callback(self.action_preempt_cb)
        self.command_action_server.start()
        # simple action client to call the local action server
        self.command_action_server_client = actionlib.SimpleActionClient('~action', RobotSimpleCommandAction)

        self.action_client = actionlib.SimpleActionClient(self.action_client_namespace, RobotSimpleCommandAction)

        return 0

    def init_state(self):
        """ Actions perfomed in init state"""
        if self.action_client.wait_for_server(rospy.Duration.from_sec(2)) == True:
            self.switch_to_state(State.READY_STATE)
        else:
            rospy.loginfo_throttle(30, "%s::init_state: waiting for command server %s..." %
                                   (self._node_name, self.action_client_namespace))

    def ready_state(self):
        """Actions performed in ready state"""

        if self.command_action_server.is_active() == True:                  # Action server running

            if self.current_sequence_list == None:                           # No sequence active

                if self.sequences_list_queue.empty() == False:               # There are pending sequences in the queue
                    self.current_sequence_list = self.sequences_list_queue.get()
                    self.current_sequence_list_id = self.current_sequence_list.get_id()
                    rospy.loginfo('%s::ready_state: Getting new sequence (%s) from the queue. %d remaining in the queue',
                                  self._node_name, self.current_sequence_list_id, self.sequences_list_queue.qsize())
                # FINISH!
                else:      # No more sequences
                    rospy.loginfo('%s::ready_state: the sequence queue is empty!', self._node_name)
                    self.finish_action(StatusCodes.SUCCEEDED)

            else:
                # No commands in execution
                if self.current_command == '':

                    current_command = self.current_sequence_list.get_next_command()

                    if current_command != None:
                        self.current_command = current_command
                        # SEND THE ACTION
                        ret, ret_msg = self.send_cmd(self.current_command)
                        if ret == True:
                            rospy.loginfo('%s::ready_state: sending new command: %s',
                                          self._node_name, self.current_command)
                        else:
                            rospy.logerr('%s::ready_state: error sending command: %s. Finishing sequence',
                                         self._node_name, self.current_command)
                            self.finish_action(StatusCodes.FAILED)

                    else:  # The sequence is finished

                        # If the sequence is in loop
                        if self.current_sequence_list.is_loop() == True:
                            rospy.logwarn('%s::ready_state: the sequence (%s) has finished but it is in loop mode! (%d cycles)',
                                          self._node_name, self.current_sequence_list.get_id(), self.current_sequence_list.get_loop_cycles())
                            self.current_sequence_list.reset()
                        else:
                            rospy.loginfo('%s::ready_state: the sequence (%s) has finished!',
                                          self._node_name, self.current_sequence_list.get_id())
                            self.current_sequence_list = None

                else:   # Waits  for the end of the command
                    self.update_feedback()
                    self.publish_feedback()

                    rospy.loginfo_throttle(5, '%s::ready_state: waiting for the end of the command: %s' %
                                           (self._node_name, self.current_command))

                    action_client_state = self.action_client.get_state()
                    communication_timeout = ((rospy.Time.now() - self.last_time_received_action_client_feedback)
                                             >= self.communication_timeout)

                    if communication_timeout == True:

                        rospy.logerr('%s::ready_state: Timeout getting feedback from the client. Command %s. Finishing sequence',
                                     self._node_name, self.current_command)
                        self.finish_action(StatusCodes.FAILED, msg='Timeout: No response from the action client')

                    elif action_client_state != GoalStatus.ACTIVE and action_client_state != GoalStatus.PENDING:

                        action_client_result = self.action_client.get_result()

                        if action_client_result == None:  # If nothing is received from get_result
                            if action_client_state == GoalStatus.SUCCEEDED:
                                rospy.loginfo('%s::ready_state: the command (%s) has finished correctly!',
                                              self._node_name, self.current_command)
                                self.current_command = ''
                            else:
                                rospy.logerr('%s::ready_state: the command (%s) has finished wrongly (goal_status = %d)!',
                                             self._node_name, self.current_command, action_client_state)
                                self.finish_action(StatusCodes.FAILED, msg="goal_status = %d" % (action_client_state))

                        elif action_client_result.result.success == True:
                            rospy.loginfo('%s::ready_state: the command (%s) has finished correctly!',
                                          self._node_name, self.current_command)
                            self.current_command = ''
                        else:
                            rospy.logerr('%s::ready_state: the command (%s) has finished wrongly (code = %d, msg = %s)!',
                                         self._node_name, self.current_command, action_client_result.result.code, action_client_result.result.message)
                            self.finish_action(StatusCodes.FAILED, msg=action_client_result.result.message)

    def shutdown(self):
        """Shutdowns device

        Return:
            0 : if it's performed successfully
            -1: if there's any problem or the component is running
        """
        self.command_sub.unregister()

        return RComponent.shutdown(self)

    def switch_to_state(self, new_state):
        """Performs the change of state"""

        return RComponent.switch_to_state(self, new_state)

    def topic_cmd_cb(self, msg):
        """Subscriber command_sub callback

        Forward the message to the action server

        Args:
            msg : CommandString object that contains the user command
        """
        if self._state != State.READY_STATE:
            rospy.logerr_throttle(5, '%s::topic_cmd_cb: command not accepted because the component is not READY' % (
                self._node_name))
            return

        if self.command_action_server.is_active() == True and self.allow_queuing == False:
            return

        is_valid, ret_msg, parsed_command = self.validate_command(msg.command)
        if is_valid == True:
            self.forward_command_to_local_action_server(msg.command)
        else:
            rospy.logerr_throttle(5, '%s::topic_cmd_cb: command %s is not valid: %s' % (
                self._node_name, msg.command, ret_msg))

    def topic_cmd_cancel_cb(self, msg):
        """Subscriber command_sub_cancel callback

        Forwards the cancel to the action server

        Args:
            msg : Empty object to cancel the current command
        """
        if self.command_action_server.is_active():
            self.cancel_command_of_local_action_server()

    def service_cmd_cb(self, msg):
        """Service command_service callback

        Forward the message to the send_cmd method

        Args:
            msg : SetCommandString object that contains the user command

        Return:
            An SetCommandStringResponse that conatins a bool and str
        """
        res = SetCommandStringResponse()

        if self._state != State.READY_STATE:
            res.ret.success = False
            res.ret.code = StatusCodes.REJECTED
            res.ret.message = "New command not accepted because the component is not READY"
            return res

        if self.command_action_server.is_active() == True and self.allow_queuing == False:
            res.ret.success = False
            res.ret.code = StatusCodes.REJECTED
            res.ret.message = "New command not allowed while another command is running"
            return res

        is_valid, ret_msg, parsed_command = self.validate_command(msg.command)
        if is_valid == True:
            self.forward_command_to_local_action_server(msg.command)
            res.ret.code = StatusCodes.ACTIVE
            res.ret.success = True
            res.ret.message = 'Command received and processed'
        else:
            res.ret.success = False
            res.ret.code = StatusCodes.REJECTED
            res.ret.message = ret_msg

        return res

    def service_cmd_cancel_cb(self, msg):
        """Service command_service_cancel callback

        Runs cancel_cmd method when recieves a cancel msg

        Args:
            msg : Trigger object to cancel the current command

        Return:
            A TriggerResponse object that contains a bool and a str
        """
        ret = TriggerResponse()

        if self.command_action_server.is_active():
            self.cancel_command_of_local_action_server()
            ret.success = True
            ret.message = 'Command correctly cancelled'
        else:
            ret.success = False
            ret.message = 'No command running to cancel'

        return ret

    def action_goal_cb(self):
        """Action server goal callback

        Accepts the new goal if not command running.  Rejects the incoming
        goal if a command is running
        """
        if self.command_action_server.is_active() == False:
            goal = self.command_action_server.accept_new_goal()
            if self._state != State.READY_STATE:
                rospy.logerr('%s::action_goal_cb: command not accepted because the component is not READY' %
                             (self._node_name))
                result = RobotSimpleCommandResult()
                result.result.command = goal.command.command
                result.result.success = False
                result.result.message = ret_msg
                result.result.code = StatusCodes.REJECTED
                self.command_action_server.set_aborted(result=result, text=result.result.message)

            is_valid, ret_msg, parsed_command = self.validate_command(goal.command.command)
            if is_valid == True:
                ret, ret_msg = self.process_command(parsed_command)
                if ret == True:
                    rospy.loginfo('%s::action_goal_cb: command %s processed. Ret = (%s, %s)',
                                  self._node_name, goal.command.command, ret, ret_msg)
                else:
                    # Aborting the action
                    rospy.logerr('%s::action_goal_cb: command %s is not valid: %s' %
                                 (self._node_name, goal.command.command, ret_msg))
                    result = RobotSimpleCommandResult()
                    result.result.command = goal.command.command
                    result.result.success = False
                    result.result.message = ret_msg
                    result.result.code = StatusCodes.REJECTED
                    self.command_action_server.set_aborted(result=result, text=result.result.message)
            else:
                # Aborting the action
                rospy.logerr('%s::action_goal_cb: command %s is not valid: %s' %
                             (self._node_name, goal.command.command, ret_msg))
                result = RobotSimpleCommandResult()
                result.result.command = goal.command.command
                result.result.success = False
                result.result.message = ret_msg
                result.result.code = StatusCodes.REJECTED
                self.command_action_server.set_aborted(result=result, text=result.result.message)
        else:

            goal = self.command_action_server.accept_new_goal()

            if self.allow_queuing == True:
                is_valid, ret_msg, parsed_command = self.validate_command(goal.command.command)
                if is_valid == True:
                    ret, ret_msg = self.process_command(parsed_command)
                    if ret == True:
                        rospy.loginfo('%s::action_goal_cb: command %s processed. Ret = (%s, %s)',
                                      self._node_name, goal.command.command, ret, ret_msg)
                    else:
                        # Aborting the action
                        rospy.logerr('%s::action_goal_cb: command %s is not valid: %s' %
                                     (self._node_name, goal.command.command, ret_msg))
                else:
                    # Not valid
                    rospy.logerr('%s::action_goal_cb: command %s is not valid: %s' %
                                 (self._node_name, goal.command.command, ret_msg))
            # do nothing -> discards the command
            else:
                rospy.logwarn(
                    '%s::action_goal_cb: New command not allowed while another command is running', self._node_name)

    def action_preempt_cb(self):
        """Action server preempt callback

        Cancels the current active goal or ignore the incoming goal if
        the preempt request has been triggered by new goal available.
        """

        if self.command_action_server.is_active():
            has_new_goal = self.command_action_server.is_new_goal_available()
            # If preempt request by new action
            if has_new_goal == False:
                self.cancel_cmd()
            else:
                rospy.logwarn(
                    '%s::action_preempt_cb: preemption due to a new command is not allowed', self._node_name)
        else:
            rospy.logwarn('%s::action_preempt_cb: No command is running', self._node_name)

    # END CALLBACKS TO MANAGE CLIENT INPUT

    def send_cmd(self, msg):
        """Sends the command to the command server

        Args:
            msg : String that contains the user command

        Return:
            Returns a tuple (bool, str) that shows if the command has been
            correctly sent
        """

        command_sent = True
        ret_msg = 'OK'

        goal = RobotSimpleCommandGoal()
        goal.command.command = msg

        try:
            self.action_client.send_goal(goal, feedback_cb=self.action_client_feedback_cb)
            self.last_time_received_action_client_feedback = rospy.Time.now()
        except Exception as e:
            command_sent = False
            msg = 'Error sending command %s' % (msg)
            rospy.logerr('%s::send_cmd: %s' % (self._node_name, ret_msg))

        return (command_sent, ret_msg)

    def cancel_cmd(self):
        """Cancels the current command running in the remote action server and finish the local action

        Return:
            True if the command has been correctly cancelled.
            False otherwihse.
        """
        self.action_client.cancel_all_goals()

        self.finish_action(StatusCodes.CANCELLED)

        rospy.logwarn('%s::cancel_cmd: Command %s correctly cancelled' %
                      (self._node_name, self.current_command))
        return True

    def split_command(self, command):
        """Splits the command from string to list of strings

        Splits the msg string to a list.

        Args:
            msg : string that contains the command

        Return:
            A list with the current command
        """
        return re.sub(' +', ' ', command).strip().split(" ")

    def cmd_is_active(self):
        """Checks if the current command is active

        Return:
            Returns a bool that shows if the command is active
        """
        # is_active = self.handlers_interfaces[self.current_handler].is_active()
        is_active = False
        return is_active

    def update_feedback(self):
        """Updates feedback messages

        Updates both feedback_msg and feedback_action_msg with information
        provided by the current_handler
        """
        try:
          current_sequence_list = self.current_sequence_list.get_current_sequence_id()
          self.feedback_msg.command = '%s:%s' % (current_sequence_list, self.current_command)
          self.feedback_msg.status = self.action_client_feedback_msg.feedback.status

          self.feedback_action_msg.feedback = self.feedback_msg
        except Exception as e:
          rospy.logerr('%s::update_feedback: %s', self._node_name, e)

    def publish_feedback(self):
        """Publishes the updated feedback
        """
        self.command_feedback_pub.publish(self.feedback_msg)
        self.command_action_server.publish_feedback(self.feedback_action_msg)

    def reject_goal(self, command):
        result = RobotSimpleCommandResult()
        result.result.command = command  # self.current_command
        result.result.success = False
        result.result.message = 'This goal has been rejected. Probably because ' +\
            'other command is running. Cancel before ' +\
            'sending other goal.'
        result.result.code = StatusCodes.REJECTED

        return

    def finish_action(self, code, msg=''):
        """Finishes the current action

        Args:
            code : int value codified as StatusCodes object
            msg: string to set the message of the result
        """
        result = RobotSimpleCommandResult()
        result.result.command = self.current_sequence_list_id
        result.result.message = msg
        result.result.code = code

        if code == StatusCodes.CANCELLED:
            result.result.success = False
            self.command_action_server.set_preempted(result=result, text=result.result.message)
        elif code == StatusCodes.SUCCEEDED:
            result.result.success = True
            self.command_action_server.set_succeeded(result=result, text=result.result.message)
        elif code == StatusCodes.FAILED:
            result.result.success = False
            self.command_action_server.set_aborted(result=result, text=result.result.message)
        else:
            result.result.success = False
            rospy.logwarn(
                '%s::finish_action: the code passed is not being handled! Setting the action as aborted', self._node_name)
            self.command_action_server.set_aborted(result=result, text=result.result.message)

        self.clear_command()

    def clear_command(self):
        """Reset some internal variables"""
        self.feedback_msg = CommandStringFeedback()
        self.feedback_action_msg = RobotSimpleCommandFeedback()
        self.current_command = ''
        self.current_sequence_list = None
        self.sequences_list_queue = Queue.Queue(self.maxsize_queue)

    def forward_command_to_local_action_server(self, command):
        """Sends the command to itself to the action server

        Args:
            command : string

        Return:
            0 if OK
            -1 if error
        """
        goal = RobotSimpleCommandGoal()
        goal.command.command = command
        self.command_action_server_client.send_goal(goal)

        return 0

    def cancel_command_of_local_action_server(self):
        """Cancels current action

        Args:


        Return:
            0 if OK
            -1 if error
        """

        self.command_action_server_client.cancel_all_goals()

        return 0

    def validate_command(self, command):
        """Checks if the command is valid (tag exists, number of arguments is correct)

        Args:
            command: string with command

        Return:
            Returns a tuple of (bool, msg, string[])
            True,msg,[parsed_command] if it is valid
            False,msg,[] if it is NOT valid
        """
        parsed_command = self.split_command(command)
        keyword_counter = 0

        for cmd in parsed_command:
            if cmd in self._sequence_reserved_keywords:
                keyword_counter += 1
            elif cmd not in self.sequences_dict:
                return False, "The sequence %s does not exist" % (cmd), []

        # At least one
        if len(parsed_command) < 1 + keyword_counter:
            return False, "Invalid command", []

        return True, "OK", parsed_command

    def process_command(self, command):
        """Processes the command and put it in the execution queue

        Args:
            command: string[] with valid sequences

        Return:
            Returns a tuple of (bool, msg)
            True,msg if it is valid
            False,msg if it is NOT valid
        """
        keyword_counter = 0

        try:
            sequence_list = SequenceList(command)
            for cmd in command:
                if cmd == 'LOOP':
                    sequence_list.set_loop(True)
                if cmd in self._sequence_reserved_keywords:
                    keyword_counter += 1
                else:
                    command_list = self.sequences_dict[cmd]
                    sequence_list.append(cmd, command_list)
                    rospy.loginfo('%s::process_command: sequence %s -> %s', self._node_name, cmd, str(command_list))
        except KeyError as e:
            return False, "Sequence %s is not valid" % (cmd)

        # At least one
        if len(command) < 1 + keyword_counter:
            return False, "Empty command"

        if sequence_list.is_loop() == True and len(command) < 2:
            return False, "Empty command"

        try:
            self.sequences_list_queue.put(sequence_list)
        except Queue.Full as e:
            return False, "Queue of sequences is full"

        return True, "OK"

    def action_client_feedback_cb(self, feedback):
        """
            Callback for the feedback from the action client
        """
        self.action_client_feedback_msg = feedback
        self.last_time_received_action_client_feedback = rospy.Time.now()
        # self.parse_feedback()

    def validate_sequence_keywords(self):
        """
            Checks that the sequences id are not reserved keywords
            In case there were, it removes them
        """
        keys_to_remove = []
        for sequence in self.sequences_dict:
            if sequence in self._sequence_reserved_keywords:
                keys_to_remove.append(sequence)

        for sequence in keys_to_remove:
            rospy.logerr(
                '%s::validate_sequence_keywords: the sequence %s is a keyword that cannot be used. It has been removed', self._node_name, sequence)
            del self.sequences_dict[sequence]
