
"use strict";

let EnterShowerPetition = require('./EnterShowerPetition.js')
let PostPlacePetition = require('./PostPlacePetition.js')
let GoToNodePetition = require('./GoToNodePetition.js')
let BatteryExchangePetition = require('./BatteryExchangePetition.js')
let SwitchMapPetition = require('./SwitchMapPetition.js')
let PlacePetition = require('./PlacePetition.js')
let MagneticNavigationPetition = require('./MagneticNavigationPetition.js')
let GoToPetition = require('./GoToPetition.js')
let UnchargePetition = require('./UnchargePetition.js')
let Cancel = require('./Cancel.js')
let StatusPetition = require('./StatusPetition.js')
let LeaveShowerPetition = require('./LeaveShowerPetition.js')
let FindMagneticGuidePetition = require('./FindMagneticGuidePetition.js')
let SetGoToPetition = require('./SetGoToPetition.js')
let PrePlacePetition = require('./PrePlacePetition.js')
let MagneticPickPetition = require('./MagneticPickPetition.js')
let MagneticPlacePetition = require('./MagneticPlacePetition.js')
let PickPetition = require('./PickPetition.js')
let ChargePetition = require('./ChargePetition.js')
let MagneticGoToPetition = require('./MagneticGoToPetition.js')
let PrePickPetition = require('./PrePickPetition.js')
let MissionCommandPetition = require('./MissionCommandPetition.js')
let SetControlState = require('./SetControlState.js')
let DockPetition = require('./DockPetition.js')
let MissionPetition = require('./MissionPetition.js')
let SetElevatorPetition = require('./SetElevatorPetition.js')
let PostPickPetition = require('./PostPickPetition.js')
let EnterLiftPetition = require('./EnterLiftPetition.js')
let MovePetition = require('./MovePetition.js')
let LeaveMagneticGuidePetition = require('./LeaveMagneticGuidePetition.js')
let LeaveLiftPetition = require('./LeaveLiftPetition.js')
let SimpleGoToWithValidation = require('./SimpleGoToWithValidation.js')

module.exports = {
  EnterShowerPetition: EnterShowerPetition,
  PostPlacePetition: PostPlacePetition,
  GoToNodePetition: GoToNodePetition,
  BatteryExchangePetition: BatteryExchangePetition,
  SwitchMapPetition: SwitchMapPetition,
  PlacePetition: PlacePetition,
  MagneticNavigationPetition: MagneticNavigationPetition,
  GoToPetition: GoToPetition,
  UnchargePetition: UnchargePetition,
  Cancel: Cancel,
  StatusPetition: StatusPetition,
  LeaveShowerPetition: LeaveShowerPetition,
  FindMagneticGuidePetition: FindMagneticGuidePetition,
  SetGoToPetition: SetGoToPetition,
  PrePlacePetition: PrePlacePetition,
  MagneticPickPetition: MagneticPickPetition,
  MagneticPlacePetition: MagneticPlacePetition,
  PickPetition: PickPetition,
  ChargePetition: ChargePetition,
  MagneticGoToPetition: MagneticGoToPetition,
  PrePickPetition: PrePickPetition,
  MissionCommandPetition: MissionCommandPetition,
  SetControlState: SetControlState,
  DockPetition: DockPetition,
  MissionPetition: MissionPetition,
  SetElevatorPetition: SetElevatorPetition,
  PostPickPetition: PostPickPetition,
  EnterLiftPetition: EnterLiftPetition,
  MovePetition: MovePetition,
  LeaveMagneticGuidePetition: LeaveMagneticGuidePetition,
  LeaveLiftPetition: LeaveLiftPetition,
  SimpleGoToWithValidation: SimpleGoToWithValidation,
};
