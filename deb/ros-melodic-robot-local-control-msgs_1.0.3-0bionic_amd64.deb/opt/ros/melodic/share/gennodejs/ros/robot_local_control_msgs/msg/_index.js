
"use strict";

let MagneticGoTo = require('./MagneticGoTo.js');
let SensorStatus = require('./SensorStatus.js');
let PrePick = require('./PrePick.js');
let Uncharge = require('./Uncharge.js');
let MissionParamString = require('./MissionParamString.js');
let Dock = require('./Dock.js');
let MissionParamBool = require('./MissionParamBool.js');
let MissionParamFloat = require('./MissionParamFloat.js');
let LeaveMagneticGuide = require('./LeaveMagneticGuide.js');
let FindMagneticGuide = require('./FindMagneticGuide.js');
let PostPlace = require('./PostPlace.js');
let MagneticNavigation = require('./MagneticNavigation.js');
let EnterShower = require('./EnterShower.js');
let Pick = require('./Pick.js');
let Move = require('./Move.js');
let Charge = require('./Charge.js');
let MissionCommand = require('./MissionCommand.js');
let MagneticPlace = require('./MagneticPlace.js');
let MissionParamInt = require('./MissionParamInt.js');
let Missions = require('./Missions.js');
let StatusArray = require('./StatusArray.js');
let RobotStatus = require('./RobotStatus.js');
let EnterLift = require('./EnterLift.js');
let Place = require('./Place.js');
let GoToNode = require('./GoToNode.js');
let MagneticPick = require('./MagneticPick.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let SwitchMap = require('./SwitchMap.js');
let Twist2D = require('./Twist2D.js');
let Status = require('./Status.js');
let LocalizationStatus = require('./LocalizationStatus.js');
let PostPick = require('./PostPick.js');
let MissionStatus = require('./MissionStatus.js');
let SetElevator = require('./SetElevator.js');
let LeaveShower = require('./LeaveShower.js');
let PrePlace = require('./PrePlace.js');
let NavigationStatus = require('./NavigationStatus.js');
let GoTo = require('./GoTo.js');
let LeaveLift = require('./LeaveLift.js');

module.exports = {
  MagneticGoTo: MagneticGoTo,
  SensorStatus: SensorStatus,
  PrePick: PrePick,
  Uncharge: Uncharge,
  MissionParamString: MissionParamString,
  Dock: Dock,
  MissionParamBool: MissionParamBool,
  MissionParamFloat: MissionParamFloat,
  LeaveMagneticGuide: LeaveMagneticGuide,
  FindMagneticGuide: FindMagneticGuide,
  PostPlace: PostPlace,
  MagneticNavigation: MagneticNavigation,
  EnterShower: EnterShower,
  Pick: Pick,
  Move: Move,
  Charge: Charge,
  MissionCommand: MissionCommand,
  MagneticPlace: MagneticPlace,
  MissionParamInt: MissionParamInt,
  Missions: Missions,
  StatusArray: StatusArray,
  RobotStatus: RobotStatus,
  EnterLift: EnterLift,
  Place: Place,
  GoToNode: GoToNode,
  MagneticPick: MagneticPick,
  Pose2DStamped: Pose2DStamped,
  SwitchMap: SwitchMap,
  Twist2D: Twist2D,
  Status: Status,
  LocalizationStatus: LocalizationStatus,
  PostPick: PostPick,
  MissionStatus: MissionStatus,
  SetElevator: SetElevator,
  LeaveShower: LeaveShower,
  PrePlace: PrePlace,
  NavigationStatus: NavigationStatus,
  GoTo: GoTo,
  LeaveLift: LeaveLift,
};
