#ifndef __PROCEDURE_COMPONENT_CHARGE_H
#define __PROCEDURE_COMPONENT_CHARGE_H

#include <procedures/procedure_component.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>
#include <procedures_msgs/ProcedureResult.h>

#include <robot_local_control_msgs/Pose2DStamped.h>
#include <robot_local_control_msgs/Twist2D.h>
#include <robot_local_control_msgs/Charge.h>
#include <robot_local_control_msgs/ChargePetition.h>

#include <std_srvs/SetBool.h>

#include <tf/transform_listener.h>

#include <boost/scoped_ptr.hpp>

#include <actionlib/client/simple_action_client.h>

#include <robotnik_navigation_msgs/DockAction.h>
#include <robotnik_navigation_msgs/MoveAction.h>

#include <robot_local_control_msgs/Status.h>

#include <robotnik_msgs/SetLaserMode.h>
#include <robotnik_msgs/LaserMode.h>

#include <regex>

struct ChargeProcedure
{
  robot_local_control_msgs::Charge procedure;
  procedures_msgs::ProcedureHeader header;
  procedures_msgs::ProcedureState state;

  typedef robot_local_control_msgs::Charge Type;
  typedef robot_local_control_msgs::ChargePetition Petition;
};

namespace procedures
{
class ProcedureComponentCharge : public ProcedureComponent<ChargeProcedure>
{
public:
  ProcedureComponentCharge();
  ProcedureComponentCharge(ros::NodeHandle h, std::string name = "ChargeComponent");

  virtual bool addProcedure(const ChargeProcedure::Petition::Request& request,
                            ChargeProcedure::Petition::Response& response);

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures(procedures_msgs::ProcedureQuery::Request& request,
                                   procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures();

  void setDockComponent(procedures::GenericProcedureComponent::Ptr component);
  void setMoveComponent(procedures::GenericProcedureComponent::Ptr component);

  enum Steps
  {
    Init = 0,
    ChangeLasersSecurity = 1,
    SetDockFrame = 2,
    Dock = 3,
    CheckChargingAfterDockFailure = 4,
    Move = 5,
    EnableChargeRelay = 6,
    SetLasersToStandby = 7
  };

protected:
  virtual void rosReadParams();
  virtual int rosSetup();
  virtual int setup();
  virtual void standbyState();
  virtual void initState();
  virtual void readyState();
  virtual std::string stepToString(int step);

  void stopActionGoals();
  bool isCharging();
  std::string getBatteryOperationMode();
  int setLasersToStandby(std::string& msg);
  void robotStatusCallback(const robot_local_control_msgs::Status& status);
  bool areLasersInStandby();
  int enableChargeRelay(std::string& msg);
  int changeLasersSecurity(std::string laser_mode, std::string& msg);
  bool isLasersInDesiredMode(std::string laser_mode);
  std::string getLaserMode();
  bool isContactRelayActive();

  template <class T>
  int checkCurrentAction(T& current_action_client)
  {
    actionlib::SimpleClientGoalState action_state = current_action_client->getState();
    if (action_state.isDone() == true)
    {
      if (action_state == actionlib::SimpleClientGoalState::SUCCEEDED)
      {
        return 0;
      }
      else
      {
        return -1;
      }
    }
    return 1;
  }

  protected:
  
  std::vector<GenericProcedureComponent::Ptr> components_;

  std::string docker_namespace_, move_namespace_;
  // int current_step_;
  bool sent_, has_safe_charge_, has_safety_laser_, set_laser_to_standby_;
  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::DockAction>> dock_action_;
  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::MoveAction>> move_action_;

  ros::Subscriber robot_status_sub_;
  robot_local_control_msgs::Status robot_status_;

  double step_in_distance_, dock_offset_x_;
  std::string battery_docking_operation_mode_, laser_mode_at_begining_;

  ros::Publisher cmd_vel_pub_;

  ros::ServiceClient enable_charge_client_;
  ros::ServiceClient laser_mode_client_;
  ros::ServiceClient set_to_standby_client_;

  std::string dock_frame_, default_dock_frame_, current_dock_frame_, generic_dock_frame_, robot_dock_frame_;
  tf::TransformListener tf_listener_;
  std::regex target_matcher_;

  geometry_msgs::Twist move_max_velocity_;
  geometry_msgs::Twist dock_max_velocity_;
  static const double min_linear_velocity_, min_angular_velocity_;
  
  //! max time to wait between step transitions
  double step_timeout_;
};
}  // namespace procedures
#endif  // __PROCEDURE_COMPONENT_CHARGE_H
