
"use strict";

let Wait = require('./Wait.js');
let Mock = require('./Mock.js');

module.exports = {
  Wait: Wait,
  Mock: Mock,
};
