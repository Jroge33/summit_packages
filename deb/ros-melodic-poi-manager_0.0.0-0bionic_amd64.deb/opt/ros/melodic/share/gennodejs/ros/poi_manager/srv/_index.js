
"use strict";

let UpdatePOIs = require('./UpdatePOIs.js')
let ReadPOIs = require('./ReadPOIs.js')

module.exports = {
  UpdatePOIs: UpdatePOIs,
  ReadPOIs: ReadPOIs,
};
