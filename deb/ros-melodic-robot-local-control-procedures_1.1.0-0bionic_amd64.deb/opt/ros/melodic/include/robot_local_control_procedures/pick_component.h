#ifndef __PROCEDURE_COMPONENT_PICK_H
#define __PROCEDURE_COMPONENT_PICK_H

#include <procedures/procedure_component.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>
#include <procedures_msgs/ProcedureResult.h>

#include <robot_local_control_msgs/Pose2DStamped.h>
#include <robot_local_control_msgs/Twist2D.h>
#include <robot_local_control_msgs/Pick.h>
#include <robot_local_control_msgs/PickPetition.h>
#include <robot_local_control_msgs/SetGoToPetition.h>

#include <tf/transform_listener.h>

#include <boost/scoped_ptr.hpp>

#include <actionlib/client/simple_action_client.h>

#include <robotnik_navigation_msgs/DockAction.h>
#include <robotnik_navigation_msgs/MoveAction.h>
#include <robotnik_msgs/SetElevatorAction.h>
#include <dynamic_reconfigure/StrParameter.h>
#include <dynamic_reconfigure/Reconfigure.h>
#include <robotnik_msgs/SetLaserMode.h>
#include <robotnik_msgs/LaserMode.h>
#include <robotnik_msgs/ElevatorStatus.h>

#include <regex>

struct PickProcedure
{
  robot_local_control_msgs::Pick procedure;
  procedures_msgs::ProcedureHeader header;
  procedures_msgs::ProcedureState state;

  typedef robot_local_control_msgs::Pick Type;
  typedef robot_local_control_msgs::PickPetition Petition;
};
namespace procedures
{
class ProcedureComponentPick : public ProcedureComponent<PickProcedure>
{
public:
  ProcedureComponentPick();
  ProcedureComponentPick(ros::NodeHandle h, std::string name = "PickComponent");

  virtual bool addProcedure(const PickProcedure::Petition::Request& request,
                            PickProcedure::Petition::Response& response);

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures(procedures_msgs::ProcedureQuery::Request& request,
                                   procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures();

  void standbyState();
  void emergencyState();
  void readyState();

  void setDockComponent(procedures::GenericProcedureComponent::Ptr component);
  void setMoveComponent(procedures::GenericProcedureComponent::Ptr component);

protected:
  virtual void rosReadParams();
  virtual int rosSetup();
  virtual int setup();

  // to be used in case internal component calling is used
  // ProcedureComponentDock::Ptr dock_component_;
  // ProcedureComponentMove::Ptr move_component_;
  // std::vector<GenericProcedureComponent::Ptr> components_;

  void stopActionGoals();
  int setElevatorUpFootprint();
  bool setMoveBaseNamespace(robot_local_control_msgs::SetGoToPetition::Request& request,
                            robot_local_control_msgs::SetGoToPetition::Response& response);

  void elevatorStatusCallback(const robotnik_msgs::ElevatorStatus& status);
  void moveStateCallback(const robotnik_msgs::State& state);
  void dockStateCallback(const robotnik_msgs::State& state);

  double step_in_distance_;

  int current_step_;
  bool sent_, has_laser_safety_;
  double dock_offset_x_;
  std::string robot_dock_frame_, default_dock_frame_, current_dock_frame_, generic_dock_frame_, elevator_up_footprint_;
  std::string docker_namespace_, move_namespace_, elevator_namespace_;
  std::regex target_matcher_;
  std::string action_namespace_;
  std::string laser_safety_mode_dock_, laser_safety_mode_raised_;
  std::string elevator_status_topic_;
  std::string move_state_topic_;
  std::string dock_state_topic_;
  bool set_dynamic_footprint_;
  tf::TransformListener tf_listener_;

  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::DockAction> > dock_action_;
  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::MoveAction> > move_action_;
  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_msgs::SetElevatorAction> > elevator_action_;
  ros::ServiceClient laser_mode_client_;

  ros::ServiceClient global_costmap_client;
  ros::ServiceClient local_costmap_client;
  ros::ServiceServer set_move_base_ac_server_;

  ros::Subscriber elevator_status_sub_;
  ros::Subscriber move_state_sub_;
  ros::Subscriber dock_state_sub_;

  robotnik_msgs::ElevatorStatus elevator_status_;
  robotnik_msgs::State move_action_server_state_;
  robotnik_msgs::State dock_action_server_state_;
};
}  // namespace procedures
#endif  // __PROCEDURE_COMPONENT_PICK_H
