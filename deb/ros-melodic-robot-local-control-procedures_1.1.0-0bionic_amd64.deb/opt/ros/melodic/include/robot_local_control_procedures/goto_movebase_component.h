#ifndef __PROCEDURE_COMPONENT_GOTO_MOVEBASE_H
#define __PROCEDURE_COMPONENT_GOTO_MOVEBASE_H

#include <procedures/procedure_component.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>
#include <procedures_msgs/ProcedureResult.h>

#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>

#include <dynamic_reconfigure/DoubleParameter.h>
#include <dynamic_reconfigure/Reconfigure.h>
#include <dynamic_reconfigure/Config.h>

#include <tf/transform_listener.h>

#include <robot_local_control_msgs/Pose2DStamped.h>
#include <robot_local_control_msgs/Twist2D.h>
#include <robot_local_control_msgs/GoTo.h>
#include <robot_local_control_msgs/GoToPetition.h>

#include <boost/scoped_ptr.hpp>

#include <robot_local_control_procedures/goto_procedure.h>
#include <robot_local_control_msgs/SetGoToPetition.h>
#include <robotnik_msgs/SetLaserMode.h>
#include <robotnik_msgs/LaserMode.h>


// TODO: finally we have to components implementing the same procedure, so we cannot
// define the struct GoToProcedure twice. We can:
// - we include it on the msg creation (will involve modifying some ros library)
// - have a common header for them in each package.
// struct GoToProcedure
//{
//  robot_local_control_msgs::GoTo procedure;
//  procedures_msgs::ProcedureHeader header;
//  procedures_msgs::ProcedureState state;
//
//  typedef robot_local_control_msgs::GoTo Type;
//  typedef robot_local_control_msgs::GoToPetition Petition;
//};

namespace procedures
{
class ProcedureComponentGoToMoveBase : public ProcedureComponent<GoToProcedure>
{
public:
  ProcedureComponentGoToMoveBase();
  ProcedureComponentGoToMoveBase(ros::NodeHandle h, std::string name = "GoToComponent");

  virtual void rosReadParams();

  bool setActionNamespace(std::string action_namespace);

  bool setGlobalFrame(std::string global_frame);

  bool setBaseFrame(std::string base_frame);

  std::string getActionNamespace();
  std::string getGlobalFrame();
  std::string getBaseFrame();

  virtual bool addProcedure(const GoToProcedure::Petition::Request& request,
                            GoToProcedure::Petition::Response& response);

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures(procedures_msgs::ProcedureQuery::Request& request,
                                   procedures_msgs::ProcedureQuery::Response& response);

  virtual bool pauseProcedure(procedures_msgs::ProcedureQuery::Request& request,
                              procedures_msgs::ProcedureQuery::Response& response);

  virtual bool resumeProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures();

  bool isGoalReached(const robot_local_control_msgs::Pose2DStamped& goal);

  bool setGoToActionClient(robot_local_control_msgs::SetGoToPetition::Request& request,
                            robot_local_control_msgs::SetGoToPetition::Response& response);

protected:
  virtual int rosSetup();

  virtual int setup();

  virtual void initState();

  virtual void standbyState();

  virtual void readyState();

protected:
  boost::scoped_ptr<actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> > action_client_;
  std::string action_namespace_;
  std::string local_planner_namespace_;

  ros::ServiceServer set_goto_ac_server_;

  ros::ServiceClient clear_costmaps_client_;
  ros::ServiceClient set_goal_tolerance_client_;
  ros::ServiceClient laser_mode_client_;
  std::string global_frame_;
  std::string base_frame_;

  tf::TransformListener tf_listener_;
  int index_of_current_goal_;
  double default_yaw_tolerance_;
  double default_xy_tolerance_;
  bool clear_costmaps_before_send_goal_;
  bool has_safety_laser_;
  int current_step_;
};
}
#endif  // __PROCEDURE_COMPONENT_GOTO_MOVEBASE_H
