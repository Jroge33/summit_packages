
"use strict";

let PingStatus = require('./PingStatus.js');

module.exports = {
  PingStatus: PingStatus,
};
