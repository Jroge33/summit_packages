
"use strict";

let InitPoseFromFrame = require('./InitPoseFromFrame.js')
let InitPoseFromMarker = require('./InitPoseFromMarker.js')
let SaveMarker = require('./SaveMarker.js')
let SaveFrame = require('./SaveFrame.js')
let SetFrameId = require('./SetFrameId.js')

module.exports = {
  InitPoseFromFrame: InitPoseFromFrame,
  InitPoseFromMarker: InitPoseFromMarker,
  SaveMarker: SaveMarker,
  SaveFrame: SaveFrame,
  SetFrameId: SetFrameId,
};
