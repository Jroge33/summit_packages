
"use strict";

let Data = require('./Data.js');
let Pose2DArray = require('./Pose2DArray.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let MotorsStatus = require('./MotorsStatus.js');
let LaserMode = require('./LaserMode.js');
let Interfaces = require('./Interfaces.js');
let encoders = require('./encoders.js');
let QueryAlarm = require('./QueryAlarm.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let MotorPID = require('./MotorPID.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let SubState = require('./SubState.js');
let StringArray = require('./StringArray.js');
let inputs_outputs = require('./inputs_outputs.js');
let Register = require('./Register.js');
let Alarms = require('./Alarms.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let AlarmSensor = require('./AlarmSensor.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let LaserStatus = require('./LaserStatus.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let Registers = require('./Registers.js');
let named_input_output = require('./named_input_output.js');
let State = require('./State.js');
let ElevatorAction = require('./ElevatorAction.js');
let BoolArray = require('./BoolArray.js');
let Axis = require('./Axis.js');
let ReturnMessage = require('./ReturnMessage.js');
let ptz = require('./ptz.js');
let MotorStatus = require('./MotorStatus.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let alarmmonitor = require('./alarmmonitor.js');
let BatteryStatus = require('./BatteryStatus.js');
let InverterStatus = require('./InverterStatus.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');

module.exports = {
  Data: Data,
  Pose2DArray: Pose2DArray,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  MotorsStatus: MotorsStatus,
  LaserMode: LaserMode,
  Interfaces: Interfaces,
  encoders: encoders,
  QueryAlarm: QueryAlarm,
  named_inputs_outputs: named_inputs_outputs,
  MotorPID: MotorPID,
  MotorHeadingOffset: MotorHeadingOffset,
  BatteryStatusStamped: BatteryStatusStamped,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  SubState: SubState,
  StringArray: StringArray,
  inputs_outputs: inputs_outputs,
  Register: Register,
  Alarms: Alarms,
  alarmsmonitor: alarmsmonitor,
  SafetyModuleStatus: SafetyModuleStatus,
  AlarmSensor: AlarmSensor,
  Pose2DStamped: Pose2DStamped,
  LaserStatus: LaserStatus,
  BatteryDockingStatus: BatteryDockingStatus,
  Registers: Registers,
  named_input_output: named_input_output,
  State: State,
  ElevatorAction: ElevatorAction,
  BoolArray: BoolArray,
  Axis: Axis,
  ReturnMessage: ReturnMessage,
  ptz: ptz,
  MotorStatus: MotorStatus,
  ElevatorStatus: ElevatorStatus,
  alarmmonitor: alarmmonitor,
  BatteryStatus: BatteryStatus,
  InverterStatus: InverterStatus,
  MotorsStatusDifferential: MotorsStatusDifferential,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorAction: SetElevatorAction,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorResult: SetElevatorResult,
  SetElevatorActionGoal: SetElevatorActionGoal,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorActionResult: SetElevatorActionResult,
};
