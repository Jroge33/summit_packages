
"use strict";

let ClearProhibitedPoints = require('./ClearProhibitedPoints.js')
let GetProhibitedPoints = require('./GetProhibitedPoints.js')
let SetProhibitedPoints = require('./SetProhibitedPoints.js')
let AddProhibitedPoints = require('./AddProhibitedPoints.js')

module.exports = {
  ClearProhibitedPoints: ClearProhibitedPoints,
  GetProhibitedPoints: GetProhibitedPoints,
  SetProhibitedPoints: SetProhibitedPoints,
  AddProhibitedPoints: AddProhibitedPoints,
};
