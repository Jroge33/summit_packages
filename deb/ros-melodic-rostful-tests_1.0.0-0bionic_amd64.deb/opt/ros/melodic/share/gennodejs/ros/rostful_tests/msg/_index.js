
"use strict";

let WaitActionResult = require('./WaitActionResult.js');
let WaitResult = require('./WaitResult.js');
let WaitActionFeedback = require('./WaitActionFeedback.js');
let WaitGoal = require('./WaitGoal.js');
let WaitFeedback = require('./WaitFeedback.js');
let WaitActionGoal = require('./WaitActionGoal.js');
let WaitAction = require('./WaitAction.js');

module.exports = {
  WaitActionResult: WaitActionResult,
  WaitResult: WaitResult,
  WaitActionFeedback: WaitActionFeedback,
  WaitGoal: WaitGoal,
  WaitFeedback: WaitFeedback,
  WaitActionGoal: WaitActionGoal,
  WaitAction: WaitAction,
};
