
"use strict";

let ptz = require('./ptz.js');
let inputs_outputs = require('./inputs_outputs.js');
let Axis = require('./Axis.js');
let ptz = require('./ptz.js');
let inputs_outputs = require('./inputs_outputs.js');
let Axis = require('./Axis.js');

module.exports = {
  ptz: ptz,
  inputs_outputs: inputs_outputs,
  Axis: Axis,
  ptz: ptz,
  inputs_outputs: inputs_outputs,
  Axis: Axis,
};
