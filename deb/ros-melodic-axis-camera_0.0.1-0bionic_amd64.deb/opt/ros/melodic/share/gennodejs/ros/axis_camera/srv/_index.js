
"use strict";

let set_ptz = require('./set_ptz.js')
let set_digital_output = require('./set_digital_output.js')

module.exports = {
  set_ptz: set_ptz,
  set_digital_output: set_digital_output,
};
