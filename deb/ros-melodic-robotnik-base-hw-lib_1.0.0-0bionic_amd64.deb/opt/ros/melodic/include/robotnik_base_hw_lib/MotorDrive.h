/*! \class RealDriver
 *  \file RealDriver.h
 *	\author Robotnik Automation S.L.L
 *	\version 1.0
 *	\date 2012
 *  \brief Class to manage the communication with the driver via CANOpen
 * (C) 2012 Robotnik Automation, SLL
 *  All rights reserved.
 */

#ifndef _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_
#define _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_

#ifndef _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_REAL_DRIVE_
#define _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_REAL_DRIVE_

#include <robotnik_base_hw_lib/PCan.h>

#define DRIVER_DIG_OUTPUTS 4
#define DRIVER_DIG_INPUTS 8
#define DRIVER_ANAG_INPUTS 1

//! Class RealDriver
class RealDriver : public Component
{
public:
  //! Internal drive status
  enum DriveStatus
  {
    UNKNOWN,
    SWITCH_ON_DISABLED,
    READY_TO_SWITCH_ON,
    OPERATION_DISABLED,
    OPERATION_ENABLED,
    FAULT,
    UNDER_VOLTAGE,
    QUICK_STOP
  };
  //! Types of CAN messages
  enum CANMessage
  {
    ENABLE_OP_MSG,
    RESET_MSG,
    SHUTDOWN_MSG,
    DIGITAL_OUTPUTS_MSG,
    DIGITAL_INPUTS_MSG,
    ANALOG_INPUTS_MSG,
    SWITCH_ON_MSG,
    DISABLE_VOLT_MSG,
    NODEGUARD_MSG,
    POSITION_SDO_MSG,
    POSITION_PDO_MSG,
    VELOCITY_SDO_MSG,
    VELOCITY_PDO_MSG,
    SYNC_MSG,
    START_COMM_MSG,
    RESET_COMM_MSG,
    RESET_NODE_MSG,
    STOP_COMM_MSG,
    PREOPERATIONAL_COMM_MSG,
    MODE_OF_OPERATION_MSG,
    HOME_OFFSET_MSG,
    HOME_METHOD_MSG,
    HOME_SPEED1_MSG,
    HOME_SPEED2_MSG,
    START_HOME_MSG,
    STOP_HOME_MSG,
    CONTROL_WORD_MSG,
    QUICK_STOP_MSG,
    CONF_RPDO1_1_MSG,
    CONF_RPDO1_2_MSG,
    CONF_RPDO21_1_MSG,
    CONF_RPDO21_2_MSG,
    CONF_RPDO22_1_MSG,
    CONF_RPDO22_2_MSG,
    CONF_TPDO1_1_MSG,
    CONF_TPDO1_2_MSG,
    CONF_TPDO3_1_MSG,
    CONF_TPDO3_2_MSG,
    CONF_TPDO4_1_MSG,
    CONF_TPDO4_2_MSG,
    CONF_TPDO21_1_MSG,
    CONF_TPDO21_2_MSG,
    CONF_TPDO22_1_MSG,
    CONF_TPDO22_2_MSG,
    DRIVE_STATUS_MSG,
    GUARD_TIME_MSG,
    LIFE_TIME_FACTOR_MSG,
    EVENT_ACTION_MSG,
    EVENT_RECOVERY_TIME_MSG,
    HEARTBEAT_CONSUMER_MSG,
    HEARTBEAT_MSG,
    ACTUAL_CURRENT_SDO_MSG,
    DC_BUS_SDO_MSG,
    ACTUAL_POSITION_SDO_MSG,
    DIGITAL_OUTPUT_UB1,
    DIGITAL_OUTPUT_UB2,
    DIGITAL_OUTPUT_UB3,
    CURRENT_LOOP_GAIN_KP,
    CURRENT_LOOP_GAIN_KI,
    PEAK_CURRENT_LIMIT_AMPS,
    PEAK_CURRENT_LIMIT_SECS,
    CONTINUOUS_CURRENT_LIMIT,
    CURRENT_FOLDBACK_TIME,
    GS0_VELOCITY_LOOP_KP,
    GS0_VELOCITY_LOOP_KI,
    GS0_VELOCITY_LOOP_KD,
    GS0_VELOCITY_LOOP_ACCEL_FEED_FORWARD,
    VELOCITY_LOOP_INTEGRATOR_DECAY
  };
  //! Status word indicators
  enum StatusWordIndicator
  {
    SW_READY_TO_SWITCH_ON = 0,
    SW_SWITCHED_ON = 1,
    SW_OP_ENABLED = 2,
    SW_FAULT = 3,
    SW_VOLTAGE_ENABLED = 4,
    SW_QUICK_STOP = 5,
    SW_SWITCH_ON_DISABLED = 6,
    SW_WARNING = 7,
    SW_DELAY = 8,
    SW_TARGET_REACHED = 10,
    SW_HOME_ATTAINED = 12,
    SW_HOMING_ERROR = 13,
    SW_CAPTURE = 14,
    SW_NUMBER = 16
  };
  //! Modes of operation of the driver
  enum ModeOfOperation
  {
    POSITION_MODE = 0x01,
    POSITION_MODE2 = 0xA8,
    VELOCITY_MODE = 0x03,
    VELOCITY_MODE2 = 0x98,
    HOME_MODE = 0x06,
    HOME_MODE2 = 0x9F,
    CURRENT_MODE = 0x04,
    CUSTOM_MODE = 0xFF,
    PVT_MODE = 0x07
  };
  //! Homing methods
  enum HomingMethod
  {
    HOME_METHOD_NEGATIVE = 0x01,
    HOME_METHOD_POSITIVE = 0x02
  };
  enum PDOTransmissionType
  {
    SYNC_ACYCLIC = 0,
    SYCN_RTR = 0xFC,
    ASYNC_RTR = 0xFD,
    ASYNC = 0xFE
  };
  // Possible event actions when an error is produced
  enum EventActionValues
  {
    EVENT_NO_ACTION = 0,
    EVENT_DISABLE_POWER = 0x01,
    EVENT_DISABLE_POSITIVE = 0x02,
    EVENT_DISABLE_NEGATIVE = 0x03,
    EVENT_DYNAMIC_BRAKE = 0x04,
    EVENT_POSITIVE_STOP = 0x05,
    EVENT_NEGATIVE_STOP = 0x06,
    EVENT_STOP = 0x07,
    EVENT_BRAKE_THEN_DISABLE_BRIDGE = 0x08,
    EVENT_BRAKE_THEN_DYNAMIC_BRAKE = 0x09,
    EVENT_BRAKE_AND_DISABLE_BRIDGE = 0x10,
    EVENT_BRAKE_AND_DYNAMIC_BRAKE = 0x11
  };
  enum DriveStatusFlags
  {
    // DRIVE BRIDGE STATUS
    DS_BRIDGE_ENABLED = 0,
    DS_DYNAMIC_BRAKE_ENABLED = 1,
    DS_SHUNT_ENABLED = 2,
    DS_POSITIVE_STOP_ENABLED = 3,
    DS_NEGATIVE_STOP_ENABLED = 4,
    DS_POSITIVE_TORQUE_INHIBIT_ACTIVE = 5,
    DS_NEGATIVE_TORQUE_INHIBIT_ACTIVE = 6,
    DS_EXTERNAL_BRAKE_ACTIVE = 7,
    // DRIVE PROTECTION STATUS
    DS_DRIVE_RESET = 8,
    DS_DRIVE_INTERNAL_ERROR = 9,
    DS_SHORT_CIRCUIT = 10,
    DS_CURRENT_OVERSHOOT = 11,
    DS_UNDER_VOLTAGE = 12,
    DS_OVER_VOLTAGE = 13,
    DS_DRIVER_OVER_TEMPERATURE = 14,
    // SYSTEM PROTECTION STATUS
    DS_PARAMETER_RESTORE_ERROR = 15,
    DS_PARAMETER_STORE_ERROR = 16,
    DS_INVALID_HALL_STATE = 17,
    DS_PHASE_SYNC_ERROR = 18,
    DS_MOTOR_OVER_TEMPERATURE = 19,
    DS_PHASE_DETECTION_FAULT = 20,
    DS_FEEDBACK_SENSOR_ERROR = 21,
    DS_MOTOR_OVER_SPEED = 22,
    DS_MAX_MEASURED_POSITION = 23,
    DS_MIN_MEASURED_POSITION = 24,
    DS_COMMUNICATION_ERROR = 25,
    // DRIVE SYSTEM STATUS 1
    DS_LOG_ENTRY_MISSED = 26,
    DS_COMMANDED_DISABLE = 27,
    DS_USER_DISABLE = 28,
    DS_POSITIVE_INHIBIT = 29,
    DS_NEGATIVE_INHIBIT = 30,
    DS_CURRENT_LIMITING = 31,
    DS_CONTINUOUS_CURRENT = 32,
    DS_CURRENT_LOOP_SATURED = 33,
    DS_USER_UNDER_VOLTAGE = 34,
    DS_USER_OVER_VOLTAGE = 35,
    DS_NONSINUSOIDAL_COMMUTATION = 36,
    DS_PHASE_DETECTION = 37,
    DS_USER_AUXILIARY_DISABLE = 38,
    DS_SHUNT_REGULATOR = 39,
    DS_PHASE_DETECTION_COMPLETE = 40,
    // DRIVE SYSTEM STATUS 2
    DS_ZERO_VELOCITY = 41,
    DS_AT_COMMAND = 42,
    DS_VELOCITY_FOLLOWING_ERROR = 43,
    DS_POSITIVE_TARGET_VELOCITY_LIMIT = 44,
    DS_NEGATIVE_TARGET_VELOCITY_LIMIT = 45,
    DS_COMMAND_LIMITER_ACTIVE = 46,
    DS_IN_HOME_POSITION = 47,
    DS_POSITON_FOLLOWING_ERROR = 48,
    DS_MAX_TARGET_POSITION_LIMIT = 49,
    DS_MIN_TARGET_POSITION_LIMIT = 50,
    DS_LOAD_MEASURED_POSITION = 51,
    DS_LOAD_TARGET = 52,
    DS_HOMING_ACTIVE = 53,
    DS_HOMING_COMPLETE = 54,
    // DRIVE SYSTEM STATUS 3
    DS_PVT_BUFFER_FULL = 55,
    DS_PVT_BUFFER_EMPTY = 56,
    DS_PVT_BUFFER_THRESHOLD = 57,
    DS_PVT_BUFFER_FAILURE = 58,
    DS_PVT_BUFFER_EMPTY_STOP = 59,
    DS_PVT_BUFFER_SEQUENCE_ERROR = 60,
    DS_COMMANDED_STOP = 61,
    DS_USER_QUICKSTOP = 62,
    DS_COMMANDED_POSITIVE_LIMIT = 63,
    DS_COMMANDED_NEGATIVE_LIMIT = 64,
    // ACTIVE CONFIGURATION STATUS
    DS_ABSOLUTE_POSITION_VALID = 65,
    DS_POSITIVE_STOP_ACTIVE = 66,
    DS_NEGATIVE_STOP_ACTIVE = 67,
    // TOTAL MESSAGES
    DS_NUMBER = 68
  };

protected:
  //! Direction of used RPDO messages
  static const int RPDO1, RPDO21, RPDO22;
  //! MSB of the direction of used RPDO messages
  static const int RPDO1_MSB, RPDO21_MSB, RPDO22_MSB;
  //! Direction of used TPDO messages
  static const int TPDO1, TPDO3, TPDO4, TPDO21, TPDO22, TPDO25, TPDO26;
  //! MSB of the direction of used TPDO messages
  static const int TPDO1_MSB, TPDO3_MSB, TPDO4_MSB, TPDO21_MSB, TPDO22_MSB, TPDO25_MSB, TPDO26_MSB;

  //! CAN device
  PCan* canDev;

public:
  //! public constructor
  RealDriver(PCan* can_device);
  //! public constructor
  ~RealDriver();
  //! Checks if the can device is initialized
  //! @return OK
  //! @return ERROR
  virtual Component::ReturnValue Setup();
  //! Sends a CAN message
  virtual Component::ReturnValue Send(byte can_id, CANMessage type, AccessMode mode, int param);  // byte can_id
};

#endif  // _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_REAL_DRIVE_

/*! \class MotorDrive
 *  \file MotorDrive.h
 *	\author Robotnik Automation S.L.L
 *	\version 3.0
 *	\date 2012
 *  \brief Class to manage the driver DPCANTE of AMC
 *
 * (C) 2010 Robotnik Automation, SLL
 *  All rights reserved.
 */

#ifndef _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_MOTOR_DRIVE_
#define _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_MOTOR_DRIVE_

#define TRAC_GEAR 12.5                            // traction gearbox 1:12.52  - 24VDC Robotnik Hub
#define MOTOR_WHEEL_DIAMETER 0.1524               // motorwheel diameter 6 inch minus deformation [M]
#define PPS_REV_VEL 48.0                          // pulses per revolution: 16 poles * 3 hall sensors
#define QUAD_VEL 1.0                              // Encoder's quadrature
#define COUNTS_PER_REV_VEL PPS_REV_VEL* QUAD_VEL  // Encoder counts per revolution

#define PPS_REV_POS 1000.0                        // pulses per revolution position axis
#define QUAD_POS 4.0                              // Encoder's quadrature
#define COUNTS_PER_REV_POS PPS_REV_POS* QUAD_POS  // Encoder counts per revolution

#define MOTOR_PI 3.14159265358979323846
#define REV_TO_METER MOTOR_WHEEL_DIAMETER* MOTOR_PI  // 1 rev -> x meters ( Diameter * Pi)
#define METER_TO_REV 1.0 / REV_TO_METER              // Constant to convert meters into revolutions
#define SPEED_SCALE_FACTOR 6.5536                    // Driver scale factor
#define NODEGUARD_TIME 100                           // Time (ms) to control the communication with the driver
#define NODEGUARD_FACTOR 5                           // factor to mult
#define HEARTBEAT_TIMER 2000                         // milliseconds
#define EVENT_RECOVERY_TIME 1000                     // milliseconds
#define BATTERY_ANALOG_INPUT 1                       // Analog input used to measure the battery
#define DEFAULT_DIGITAL_INPUT_ESTOP 1
//#define DIGITAL_INPUT_ESTOP 0x01

#define NMT_TIMEOUT 2  // Max timeout (seconds) on the communication with the drivers

#define STATUS_REGISTER_WORDS 7

#define MAX_CTRL_PARAMS 9
#define AUXILIARY_THREADS_HZ 5.0

enum
{
  DRIVE_STATUS_FLAG_TIMER =
      3000000,  // 3000000 uSecs = 3s Timer to generate an alarm when a drive status flag is active
  DRIVE_STATUS_CONTROL_TIMER = 500000,  // 500000 uSecs = 50 ms = 0.05 s Timer to try to switch to the desired status

};

typedef struct KinematicParams
{
  bool calculate_vel_using_pose;
  double wheel_diameter;
  double gearbox_ratio;
  bool has_encoder;
  double encoder_factor;
  double motor_velocity_spin;
  double motor_position_home_offset;
  bool home_required;
  int home_method;
  bool homing_at_startup;
  int low_position_limit;
  int high_position_limit;
} KinematicParams;

typedef struct ControlParams
{
  double current_kp;
  double current_ki;
  double peak_current_limit_amps;
  double peak_current_limit_secs;
  double current_foldbacks_secs;
  double velocity_kp;
  double velocity_ki;
  double velocity_kd;
  double continuous_current_limit;
  double max_rated_peak_current_drive;

} ControlParams;

//! Main function to execute into test secondary thread
void* AuxMotorDriveControlCommunicationThread(void* threadParam);
//! Main function to execute into the third thread
void* AuxMotorDriveReadSDOMessagesThread(void* threadParam);

//! Class MotorDrive
class MotorDrive : public RealDriver
{
  friend void* AuxMotorDriveControlCommunicationThread(void* threadParam);
  friend void* AuxMotorDriveReadSDOMessagesThread(void* threadParam);

public:
  //! Struct to store the value of digital inputs / outputs
  typedef struct Digital
  {
    //! Value for a maximum of 32 I/O
    unsigned int uiValue;
    //! Value of I/O using a vector
    bool bValue[32];
  } Digital;

protected:
  //! Can identifier
  byte CanId;
  //! Digital Inputs
  Digital digitalInputs;
  //! Digital Outputs (Desired value and read value from device)
  Digital digitalOutputs, digitalRealOutputs;
  //! Number of digital outputs
  static const unsigned int uiNumOfDigOut;
  //! Number of digital inputs
  static const unsigned int uiNumOfDigIn;
  //! Number of analog inputs
  static const unsigned int uiNumOfAnagIn;
  //! CAN communication status
  CommunicationStatus commStatus;
  //! Contains the values of the analog inputs
  double dAnalogInputs[DRIVER_ANAG_INPUTS];
  //! Time of the last NodeGuard reply from the drive
  struct timespec tNodeGuardReply;
  //! Internal status of the drive
  DriveStatus dsStatus;
  //! Internal desired status of the drive
  DriveStatus dsDesiredStatus;
  //! Temperature of the drive
  double dTemperature;
  //! Status' flags of the drive
  bool bStatusWord[16];
  //! Drive Status flags (provided by CAN object 0x2002h)
  int16_t iDriveStatus[STATUS_REGISTER_WORDS];
  //! Manufacturer register status' flags of the drive. Flag for all the drive status bit provided by CAN 0x2002h object
  bool bStatusRegister[DS_NUMBER], bLastStatusRegister[DS_NUMBER];
  //! Vector to control the duration of an active flag to avoid too many logs
  struct timespec tStatusRegisterTimer[DS_NUMBER];
  //! Mascara con los flags que hay que controlar de forma peridica
  bool bStatusRegisterMask[DS_NUMBER];
  //! Controla que se hayan leido todos los status register
  bool bStatusRegisterRead[STATUS_REGISTER_WORDS];
  //! Flag para la lectura del registro de estado del driver
  bool bRegisterError;
  //! Flag to force the reset of the driver
  bool bForceReset;
  //! Delay between consecutive CAN transmissions (nanoseconds)
  static const unsigned int uiDelayTrans;
  //! Mode of operation of the drive
  ModeOfOperation modModeOfOperation;
  //! Velocity ref of the motor
  int32_t iVelocityRef;
  //! Position ref of the motor
  int32_t iPositionRef;
  //! Actual Position of the motor
  int32_t iPositionActual;
  int32_t iLowPositionLimit, iHighPositionLimit;
  //! Actual Velocity of the motor
  int32_t iVelocityActual;
  //! Set when the homing method has been correctly executed
  bool bHomingComplete;
  //! homing at startup
  bool bHomingAtStartUp;
  //! Set when homing is not needed (because it has been executed or has been done previously)
  bool bHasAbsolutePositionValid;
  bool bHadAbsolutePositionValidInThePast;
  bool bHomingRequired;
  //! Timer to control the transitions of internal drive state
  struct timespec tControlWord;
  //! Flags to read the analog inputs
  bool bAnalogEnable[DRIVER_ANAG_INPUTS];
  //! Enables/disables log of the Drive Status
  bool bLogDriveStatus;
  //! Value of the instant consumed current, and the average (every second)
  double dInstantCurrent, dAverageCurrent;
  //! Value of the instant battery value, and the average (every second)
  double dInstantBattery, dAverageBattery;
  //! Value of the DC Bus Voltage
  double dDCBusVoltage;
  //! First Cicle
  bool bFirstCicle;
  //! Emergency Stop Push/Release to Reset
  bool bEmergencyStopToReset;
  bool bHasPositionLimits;
  //! Parameters of the servo amplifier control loop
  ControlParams* motor_ctrl_params;
  //! Home method number defined by CANOpen
  int iHomeMethod;

public:
  //! public constructor
  MotorDrive(byte can_id, PCan* can_device, double desired_hz, struct ControlParams* ctrl_params);
  //! public constructor
  ~MotorDrive();
  //! Setups the component
  //! @return OK
  //! @return ERROR
  virtual Component::ReturnValue Setup();
  //! Closes and frees the reserved resources
  //! @return OK
  //! @return ERROR if fails when closes the devices
  //! @return RUNNING if the component is running
  //! @return NOT_INITIALIZED if the component is not initialized
  virtual Component::ReturnValue ShutDown();
  //! Starts the control thread of the component and its subcomponents
  //! @return OK
  //! @return ERROR starting the thread
  //! @return RUNNING if it's already running
  //! @return NOT_INITIALIZED if it's not initialized
  Component::ReturnValue Start();
  //! Gets the communication status
  CommunicationStatus GetCommunicationStatus();
  //! Gets the communication status like a string
  std::string GetCommunicationStatusString();
  //! Puts CAN communication in Operational state
  //! @return OK
  //! @return ERROR
  Component::ReturnValue StartCANCommunication();
  //! Resets the communication control state machine
  //! @return OK
  //! @return ERROR
  Component::ReturnValue ResetCANCommunication();
  //! Stops the communication control state machine to STOPPED state
  //! @return OK
  //! @return ERROR
  Component::ReturnValue StopCANCommunication();
  //! Resets the CAN node and its configuration
  //! @return OK
  //! @return ERROR
  Component::ReturnValue ResetNode();
  //! Change the communication control state machine to PRE-OPERATIONAL state
  //! @return OK
  //! @return ERROR
  Component::ReturnValue PreoperationalCANCommunication();
  //! Process received CAN messages
  //! @param msg as a TPCANMsg, the message to process
  void ProcessCANMessage(TPCANMsg msg);

  //! Function to get the status of the drive
  //! @return the status of the motor drive
  DriveStatus GetDriveStatus();
  //! Function to get the status of the drive
  //! @return the status of the motor drive
  std::string GetDriveStatusString();
  std::string GetDriveStatusString(DriveStatus status);
  //!  Returns the string value of the selected status word
  std::string GetDriveStatusWordIndicatorString(DriveStatusFlags flag);
  //!  Returns the string value of all active status word
  std::vector<std::string> GetFullDriveStatusWordIndicatorString();
  //! Gets drive's mode of operation
  ModeOfOperation GetModeOfOperation();
  //! Returns the value of the internal status word as a string
  std::string GetDriveStatusWordString();
  //! Returns the value of the internal status word as a string
  std::string GetDriveStatusRegisterFlagsString();
  //!  Returns the string value of all active drive status flags
  std::vector<std::string> GetFullDriveStatusRegisterString();
  //! Returns the value of the internal status word as an array
  bool* GetDriveStatusRegister();
  //! Sets the desired status of the driver
  void SetDesiredStatus(DriveStatus new_status);

  //! Function to get the value of all digital inputs
  //! @return drive's digital inputs as an unsigned integer
  //! @return ERROR
  unsigned int GetDigitalInputs();
  //! function for getting the selected digital input value
  //! @return true
  //! @return false
  bool GetDigitalInput(unsigned int input);
  //! Function to get the selected analog input value
  double GetAnalogInput(unsigned int input);
  //! Function to set the value of the digital outputs
  //! @param Outputs as unsigned int, value of the digital outputs
  //! @return OK
  //! @return ERROR
  Component::ReturnValue SetDigitalOutputs(unsigned int output);
  //! Function to set drive's digital outputs
  //! @param index as int, number of the digital output
  //! @param value as bool, value of the digital output
  //! @return OK
  //! @return ERROR
  Component::ReturnValue SetDigitalOutputs(unsigned int index, bool value);
  //! Function to get the values of the digital outputs
  //! @return drive's digital outputs
  unsigned int GetDigitalOutputs();
  //! Function for getting the selected digital output value
  //! @return true
  //! @return false
  bool GetDigitalOutput(unsigned int output);
  //! Function to send SYNC message by the CAN network
  Component::ReturnValue Syncronize();
  //! Gets the value of internal drive status object
  int16_t GetDriveStatus(int object);
  //! Prints / Logs the value of every Drive Status flag
  void PrintDriveStatusRegister();
  //!	Returns the string value of the selected flag
  std::string GetDriveStatusRegisterString(DriveStatusFlags flag);
  //! Enables / disables the log of DriveStatus object
  void SetLogDriveStatus(bool value);
  //! Gets the CAN ID
  byte GetCanId();
  //! Gets the consumed current
  double GetCurrent();
  //! Gets the average of battery level
  double GetBattery();
  //! Gets the voltage in the power bus
  double GetDCBusVoltage();
  //! Sets peak current limit
  ReturnValue SetPeakCurrentLimit(float current);

  //! Checks if MotorDrive needs to be homed, depending on the joint type. If joint must not be homed, IsHomingNeeded
  //! will always return false
  virtual bool IsHomingRequired();
  virtual bool IsHomingRequiredAtStartUp();
  //! Checks if MotorDrive must be homed because it has lost its homing position
  virtual bool IsHomingNeeded();
  bool HasLostAbsolutePositionValid();
  bool getAbsoluteValidPositionValid();
  bool HasReadAllStatusRegister();
  bool HasHitPositionLimit();
  bool IsBetweenPositionLimits();
  //! Returns if input command is valid
  virtual bool IsCommandValid(const double command);

protected:
  //! Configures devices and performance of the component
  //! @return OK
  //! @return ERROR, if the configuration process fails
  Component::ReturnValue Configure();
  //! Configures CAN TPDOs and RPDOs
  //! @return OK
  //! @return ERROR, if the configuration process fails
  Component::ReturnValue ConfigureCANMsgs();
  //! SDO configuration messages
  Component::ReturnValue ConfigureUserMsgs();
  //! Actions performed on initial state
  virtual void InitState();
  //! Actions performed on ready state
  virtual void ReadyState();
  //! Actions performed on restart state
  virtual void RestartState();
  //! Actions performed on failure state
  virtual void FailureState();

  //! Actions performed on the emergency state
  virtual void EmergencyState();
  //! Actions performed in all states
  virtual void AllState();
  //! Change the value of the communication status
  void SwitchToCommunicationStatus(CommunicationStatus new_status);
  //! Change the value of the communication status
  void SwitchToStatus(DriveStatus new_status);
  //! Process received CAN TPDO1 messages (Default COB-ID= 0x180 + node id).
  //! @param msg as a TPCANMsg, the message to process
  void ProcessTPDO1Msg(TPCANMsg msg);
  //! Process received CAN TPDO22 messages (Default COB-ID= 0x280 + node id).
  //! This type of message contains the following data from Motor Drive:
  //! Velocity Actual Value (4 bytes)
  //! @param msg as a TPCANMsg, the message to process
  void ProcessTPDO22Msg(TPCANMsg msg);
  //! Process received CAN TPDO21 messages (Default COB-ID= 0x280 + node id).
  //! This type of message contains the following data from Motor Drive:
  //! Position Actual Value (4 bytes)
  //! @param msg as a TPCANMsg, the message to process
  void ProcessTPDO21Msg(TPCANMsg msg);
  //! Process the value of the digital inputs received from the drive
  void ProcessDigitalInputs(TPCANMsg msg);
  //! Process the value of the digital Outputs received from the drive
  void ProcessDigitalOutputs(TPCANMsg msg);
  //! Process the value of the analog inputs received from the drive
  void ProcessAnalogInputs(TPCANMsg msg);
  //! Process the mode of operation message read from the drive
  void ProcessModeOfOperation(TPCANMsg msg);
  //! Process the status_word value received from the drive and changes the status of the object
  //! @param status_word as a byte, with the current drive internal status
  void ProcessStatusWord(TPCANMsg msg);
  //! Process received CAN SDO message (Default COB-ID= 0x60ff).
  //! This type of message contains the following data from Motor Drive:
  //! Velocity Actual Value (4 bytes)
  //! @param msg as a TPCANMsg, the message to process
  void ProcessVelocityValue(TPCANMsg msg);
  //! Process received CAN SDO message (Default COB-ID= 0x606C).
  //! This type of message contains the following data from Motor Drive:
  //! Velocity Actual Value (4 bytes) Measured post-filter
  //! @param msg as a TPCANMsg, the message to process
  void ProcessActualVelocityValue(TPCANMsg msg);
  //! Process received CAN SDO message (Default COB-ID= 0x607A).
  //! This type of message contains the following data from Motor Drive:
  //! Position Ref Value (4 bytes)
  //! @param msg as a TPCANMsg, the message to process
  void ProcessPositionValue(TPCANMsg msg);
  //! Process received CAN SDO message (Default COB-ID= 0x6064).
  //! This type of message contains the following data from Motor Drive:
  //! Position Ref Value (4 bytes)
  //! @param msg as a TPCANMsg, the message to process
  void ProcessActualPositionValue(TPCANMsg msg);
  //! Process received CAN SDO message (COB-ID = 0x200F.01)
  //! Contains - DC BUS Voltage (4 bytes) in DV1 units
  //! @param msg as a TPCANMsg, the message to process
  void ProcessDCBusVoltage(TPCANMsg msg);
  //! Process received CAN SDO message (Default COB-ID= 0x2002).
  //! This type of message contains the following data from Motor Drive:
  //! Drive Status Message
  //! @param msg as a TPCANMsg, the message to process
  void ProcessDriveStatus(TPCANMsg msg);

  int ProcessInt16Message(TPCANMsg msg);
  int ProcessInt32Message(TPCANMsg msg);

  //! Actions to control the communication state with the drive
  void ControlCommunicationThread();
  //! Sleeps for a moment
  void Delay();
  void Delay(unsigned int value);
  //! Reset and initialize the status of the drive
  //! @return OK
  //! @return ERROR
  virtual Component::ReturnValue Initialize();
  //! Reads SDO messages from the device
  void ReadSDOMessagesThread();
  //! Configures RPDO messages of the drive
  Component::ReturnValue ConfigureRPDO(unsigned int rpdo_num);
  //! Configures TPDO messages
  Component::ReturnValue ConfigureTPDO(unsigned int tpdo_num, byte sync_cycles, bool enable);
  //! Configures timer for nodeguard
  Component::ReturnValue ConfigureNodeGuardTimer();
  //! Process the current consumed by the motors
  void ProcessCurrent(TPCANMsg msg);
  //! Initializes the status register mask
  void InitStatusRegister();
};

#endif  // _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_MOTOR_DRIVE_

#endif  // _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_
