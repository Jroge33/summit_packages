#ifndef _ROBOT_LOCAL_CONTROL_MISSION_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_MISSION_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control/robot_local_control_component.h>

namespace robot_local_control
{
class MissionComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  MissionComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "MissionComponent")
  {
  }
  virtual ~MissionComponentBase()
  {
  }
  static inline std::string getBaseType()
  {
    return std::string("MissionComponent");
  }
  virtual std::string getType()
  {
    return getBaseType();
  }
};

}  // namespace
#endif //_ROBOT_LOCAL_CONTROL_MISSION_COMPONENT_BASE_
