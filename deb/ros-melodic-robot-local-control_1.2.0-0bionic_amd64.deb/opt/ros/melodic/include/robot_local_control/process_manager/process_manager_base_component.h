#ifndef _ROBOT_LOCAL_CONTROL_PROCESS_MANAGER_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_PROCESS_MANAGER_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control/robot_local_control_component.h>

namespace robot_local_control
{
class ProcessManagerComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  ProcessManagerComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "ProcessManagerComponent")
  {
  }

  virtual ~ProcessManagerComponentBase()
  {
  }
  static inline std::string getBaseType()
  {
    return std::string("ProcessManagerComponent");
  }
  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual std::string getNodeCurrentState(std::string, std::string) = 0;
  virtual std::string getNodeCurrentState(std::string, std::string, std::string) = 0;
  virtual bool toggleNode(std::string, std::string, int) = 0;
  virtual bool toggleNode(std::string, std::string, std::string, int) = 0;
};

}  // namespace
#endif  //_ROBOT_LOCAL_CONTROL_PROCESS_MANAGER_COMPONENT_
