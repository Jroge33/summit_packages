#ifndef _ROBOT_LOCAL_CONTROL_CONTROL_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_CONTROL_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control/robot_local_control_component.h>

#include <robot_local_control_msgs/SetControlState.h>

namespace robot_local_control
{
class ControlComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  ControlComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "ControlComponent")
    : robot_local_control::RobotLocalControlComponent(h, name)
  {
  }

  virtual ~ControlComponentBase()
  {
  }

  static inline std::string getBaseType()
  {
    return std::string("ControlComponent");
  }

  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual bool setDesiredControlState(std::string desired_state) = 0;

  virtual std::string getCurrentControl() = 0;
};

}  // namespace
#endif  //_ROBOT_LOCAL_CONTROL_CONTROL_COMPONENT_BASE_
