#ifndef _ROBOT_LOCAL_CONTROL_SIGNAL_MANAGER_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_SIGNAL_MANAGER_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control_msgs/SignalManager.h>

#include <robot_local_control/robot_local_control_component.h>

namespace robot_local_control
{
class SignalManagerComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  SignalManagerComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "SignalManagerComponent")
  {
  }

  virtual ~SignalManagerComponentBase()
  {
  }
  static inline std::string getBaseType()
  {
    return std::string("SignalManagerComponent");
  }
  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual robot_local_control_msgs::SignalManager getCurrentStatus() = 0;
};

}  // namespace
#endif //_ROBOT_LOCAL_CONTROL_SIGNAL_MANAGER_COMPONENT_
