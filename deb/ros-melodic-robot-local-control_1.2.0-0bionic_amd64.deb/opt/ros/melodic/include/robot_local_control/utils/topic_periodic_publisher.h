#ifndef _ROBOT_LOCAL_CONTROL_TOPIC_PERIODIC_PUBLISHER_
#define _ROBOT_LOCAL_CONTROL_TOPIC_PERIODIC_PUBLISHER_

#include <ros/ros.h>

//! Class to send data at a certain period

template <class T>
class TopicPeriodicPublisher
{
private:
  //! at which frequency we want to publish the data
  double period_;

  //! if true, will publish when data is updated
  bool publish_on_update_;

  //! message we want to publish
  T msg_;

  //! reference to the publisher
  ros::Publisher* pub_;

  //! timer to execute callback
  ros::Timer timer_;

  //! handle
  ros::NodeHandle n_;

public:
  ~TopicPeriodicPublisher()
  {
  }
  TopicPeriodicPublisher(ros::Publisher* publisher, double period, bool publish_on_update = false)
  {
    pub_ = publisher;
    period_ = period;
    publish_on_update_ = publish_on_update;

    timer_ = n_.createTimer(ros::Duration(period_), &TopicPeriodicPublisher::timerCallback, this);
  }
  void setMsg(T& msg)
  {
    msg_ = msg;
    if (publish_on_update_)
      publish();
  }

  void timerCallback(const ros::TimerEvent&)
  {
    publish();
  }

  void publish()
  {
    pub_->publish(msg_);
  }

  void enable()
  {
    timer_.start();
  }

  void disable()
  {
    timer_.stop();
  }
};

#endif //_ROBOT_LOCAL_CONTROL_TOPIC_PERIODIC_PUBLISHER_
